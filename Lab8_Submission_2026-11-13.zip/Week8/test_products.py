import json
import os
import tempfile
from unittest.mock import patch

import unittest
from io import StringIO
from contextlib import redirect_stdout

if __package__:
    from . import main
else:
    import main

Product = main.Product
Inventory = main.Inventory
PhysicalProduct = main.PhysicalProduct
DigitalProduct = main.DigitalProduct
CanBeShipped = main.CanBeShipped
Supplier = main.Supplier
Order = main.Order


def show_product_details(product: Product) -> None:
    product.display_information()
    print(product.get_fulfilment_info())


class TestProductOverriding(unittest.TestCase):

    def setUp(self):
        self.supplier = Supplier("S001", "Test supplier", "test@example.com")

    def test_physical_product_display(self):
        product = PhysicalProduct("P001", "Laptop", 1200, 5, 2.5, self.supplier)

        output = StringIO()

        with redirect_stdout(output):
            product.display_information()

        result = output.getvalue()

        self.assertIn("P001", result)
        self.assertIn("Laptop", result)
        self.assertIn("1200.00", result)
        self.assertIn("Stock: 5", result)
        self.assertIn("Weight: 2.5 kg", result)

    def test_digital_product_display(self):
        product = DigitalProduct("D001", "Antivirus", 49.90, 20, 500, self.supplier)

        output = StringIO()

        with redirect_stdout(output):
            product.display_information()

        result = output.getvalue()

        self.assertIn("D001", result)
        self.assertIn("Antivirus", result)
        self.assertIn("49.90", result)
        self.assertIn("Stock: 20", result)
        self.assertIn("Download Size: 500 MB", result)
    
    def test_physical_fulfilment(self):
        product = PhysicalProduct("P001", "Laptop", 1200, 5, 2.5, self.supplier)

        result = product.get_fulfilment_info()

        self.assertEqual(
            result,
            "This product requires physical shipping."
        )

    def test_digital_fulfilment(self):
        product = DigitalProduct("D001", "Antivirus", 49.90, 20, 500, self.supplier)

        result = product.get_fulfilment_info()

        self.assertEqual(
            result,
            "This product is delivered digitally."
        )

    def test_product_cannot_be_instantiated(self):
        with self.assertRaises(TypeError):
            Product("P002", "Generic", 10, 5, self.supplier)
    
    def test_physical_shipping_cost(self):
        product = PhysicalProduct("P001", "Laptop", 1200, 5, 2.5, self.supplier)

        self.assertEqual(product.calculate_shipping_cost(), 12.50)

    def test_shipping_cost_different_weight(self):
        product = PhysicalProduct("P002", "Monitor", 300, 3, 5.0, self.supplier)

        self.assertEqual(product.calculate_shipping_cost(), 25.00)

    def test_digital_product_has_no_shipping(self):
        product = DigitalProduct("D001", "Antivirus", 49.90, 20, 500, self.supplier)

        self.assertFalse(hasattr(product, "calculate_shipping_cost"))
    
    def test_interface_cannot_be_instantiated(self):
        with self.assertRaises(TypeError):
            CanBeShipped()

class TestInventoryIntegration(unittest.TestCase):

    def setUp(self):
        self.supplier = Supplier("S001", "Test supplier", "test@example.com")

    def test_add_both_product_types(self):
        inventory = Inventory()

        physical = PhysicalProduct("P001", "Laptop", 1200, 5, 2.5, self.supplier)
        digital = DigitalProduct("D001", "Antivirus", 49.90, 20, 500, self.supplier)

        inventory.add_product(physical)
        inventory.add_product(digital)

        self.assertEqual(len(inventory._products), 2)
        self.assertIsInstance(inventory.search_product("P001"), PhysicalProduct)
        self.assertIsInstance(inventory.search_product("D001"), DigitalProduct)

    def test_physical_json_data(self):
        product = PhysicalProduct("P001", "Laptop", 1200, 5, 2.5, self.supplier)

        data = product.to_dict()

        self.assertEqual(data["type"], "physical")
        self.assertEqual(data["weight"], 2.5)
        self.assertEqual(data["stock"], 5)

    def test_digital_json_data(self):
        product = DigitalProduct("D001", "Antivirus", 49.90, 20, 500, self.supplier)

        data = product.to_dict()

        self.assertEqual(data["type"], "digital")
        self.assertEqual(data["download_size"], 500)
        self.assertEqual(data["price"], 49.90)

    def test_save_and_load_inventory(self):
        with tempfile.TemporaryDirectory() as folder:
            test_file = os.path.join(folder, "inventory.json")

            with patch.object(main, "INVENTORY_FILE", test_file):
                inventory = Inventory()

                inventory.add_product(
                    PhysicalProduct("P001", "Laptop", 1200, 5, 2.5, self.supplier)
                )
                inventory.add_product(
                    DigitalProduct("D001", "Antivirus", 49.90, 20, 500, self.supplier)
                )

                main.save_inventory(inventory)

                with open(test_file, "r") as file:
                    saved_data = json.load(file)

                self.assertEqual(len(saved_data), 2)

                loaded = main.load_inventory()

                physical = loaded.search_product("P001")
                digital = loaded.search_product("D001")

                self.assertIsInstance(physical, PhysicalProduct)
                self.assertIsInstance(digital, DigitalProduct)
                self.assertEqual(physical._weight, 2.5)
                self.assertEqual(digital._download_size, 500)

    def test_legacy_json_rejected_safely(self):
        with tempfile.TemporaryDirectory() as folder:
            test_file = os.path.join(folder, "inventory.json")

            legacy_data = [
                {"id": "1", "name": "6", "price": 231.0, "stock": 1}
            ]

            with open(test_file, "w") as file:
                json.dump(legacy_data, file)

            with patch.object(main, "INVENTORY_FILE", test_file):
                with patch("sys.stdout", new_callable=StringIO):
                    with self.assertRaises(ValueError):
                        main.load_inventory()

            with open(test_file, "r") as file:
                self.assertEqual(json.load(file), legacy_data)
    
    def test_physical_product_implements_shipping_interface(self):
        self.assertTrue(issubclass(PhysicalProduct, CanBeShipped))
        self.assertFalse(issubclass(DigitalProduct, CanBeShipped))

    def test_update_stock(self):
        product = PhysicalProduct("P001", "Laptop", 1200, 5, 2.5, self.supplier)

        self.assertTrue(product.update_stock(10))
        self.assertEqual(product._stock, 10)
        self.assertFalse(product.update_stock(-5))
        self.assertEqual(product._stock, 10)

class TestSupplierAssociation(unittest.TestCase):
    def setUp(self):
        self.supplier = Supplier("S001", "Test supplier", "test@example.com")
        self.physical = PhysicalProduct("P001", "Laptop", 1200, 5, 2.5, self.supplier)
        self.digital = DigitalProduct("D001", "Antivirus", 49.90, 20, 500, self.supplier)
        self.folder = tempfile.TemporaryDirectory()
        self.addCleanup(self.folder.cleanup)
        self.test_file = os.path.join(self.folder.name, "inventory.json")
        self.file_patch = patch.object(main, "INVENTORY_FILE", self.test_file)
        self.file_patch.start()
        self.addCleanup(self.file_patch.stop)

    def write_records(self, records):
        with open(self.test_file, "w") as file:
            json.dump(records, file)

    def read_file(self):
        with open(self.test_file, "r") as file:
            return file.read()

    def test_both_products_retain_supplied_object(self):
        self.assertIs(self.physical.supplier, self.supplier)
        self.assertIs(self.digital.supplier, self.supplier)
        self.assertIsNot(self.physical, self.supplier)
        self.assertIsNot(self.digital, self.supplier)

    def test_supplier_display_through_both_products(self):
        for product in (self.physical, self.digital):
            with self.subTest(product=type(product).__name__):
                output = StringIO()
                with redirect_stdout(output):
                    product.display_information()
                self.assertIn("Supplier: S001", output.getvalue())
                self.assertIn("Test supplier", output.getvalue())
                self.assertIn("test@example.com", output.getvalue())

    def test_supplier_validates_required_details(self):
        for details in (("", "Name", ""), ("S1", " ", ""),
                        (None, "Name", ""), ("S1", "Name", None),
                        ("UNKNOWN", "Real company", "")):
            with self.subTest(details=details), self.assertRaises(ValueError):
                Supplier(*details)

    def test_blank_email_is_displayed_as_unavailable(self):
        supplier = Supplier("S002", "No contact", "")
        output = StringIO()
        with redirect_stdout(output):
            supplier.display_information()
        self.assertIn("Email: Not provided", output.getvalue())

    def test_round_trip_preserves_details_and_shared_identity(self):
        inventory = Inventory()
        inventory.add_product(self.physical)
        inventory.add_product(self.digital)
        main.save_inventory(inventory)
        saved = json.loads(self.read_file())
        self.assertEqual(saved[0]["supplier"], self.supplier.to_dict())
        loaded = main.load_inventory()
        physical = loaded.search_product("P001")
        digital = loaded.search_product("D001")
        self.assertEqual(physical.supplier.to_dict(), self.supplier.to_dict())
        self.assertIs(physical.supplier, digital.supplier)
        self.assertIsInstance(physical, PhysicalProduct)
        self.assertIsInstance(digital, DigitalProduct)

    def test_typed_week7_records_migrate_only_on_save(self):
        records = [self.physical.to_dict(), self.digital.to_dict()]
        for record in records:
            record.pop("supplier")
        self.write_records(records)
        before = self.read_file()
        inventory = main.load_inventory()
        self.assertEqual(self.read_file(), before)
        supplier = inventory.search_product("P001").supplier
        self.assertEqual(supplier.to_dict(), {
            "supplier_id": "UNKNOWN", "name": "Unknown supplier", "contact_email": ""
        })
        self.assertIs(supplier, inventory.search_product("D001").supplier)
        main.save_inventory(inventory)
        loaded = main.load_inventory()
        self.assertEqual(loaded.search_product("P001").supplier.to_dict(), supplier.to_dict())

    def test_malformed_supplier_records_rejected_without_write(self):
        for supplier_data in (None, "S001", {},
                              {"supplier_id": "S001", "name": "Test", "contact_email": 7}):
            with self.subTest(supplier_data=supplier_data):
                record = self.physical.to_dict()
                record["supplier"] = supplier_data
                self.write_records([record])
                before = self.read_file()
                with redirect_stdout(StringIO()), self.assertRaises((ValueError, KeyError)):
                    main.load_inventory()
                self.assertEqual(self.read_file(), before)

    def test_conflicting_supplier_details_rejected_without_write(self):
        records = [self.physical.to_dict(), self.digital.to_dict()]
        records[1]["supplier"]["name"] = "Different company"
        self.write_records(records)
        before = self.read_file()
        with redirect_stdout(StringIO()), self.assertRaisesRegex(ValueError, "Conflicting"):
            main.load_inventory()
        self.assertEqual(self.read_file(), before)

    def test_missing_file_starts_empty(self):
        with redirect_stdout(StringIO()):
            inventory = main.load_inventory()
        self.assertEqual(inventory._products, [])
        self.assertFalse(os.path.exists(self.test_file))

    def test_cli_creates_supplier_then_reuses_it_for_other_subtype(self):
        inventory = Inventory()
        with patch("builtins.input", side_effect=[
                "1", "P001", "Laptop", "1200", "5", "2.5",
                "S001", "Test supplier", "test@example.com"
        ]), redirect_stdout(StringIO()):
            main.menu_add_product(inventory)
        with patch("builtins.input", side_effect=[
                "2", "D001", "Antivirus", "49.90", "20", "500", "S001"
        ]), redirect_stdout(StringIO()):
            main.menu_add_product(inventory)
        physical = inventory.search_product("P001")
        digital = inventory.search_product("D001")
        self.assertIsInstance(physical, PhysicalProduct)
        self.assertIsInstance(digital, DigitalProduct)
        self.assertIs(physical.supplier, digital.supplier)
        self.assertEqual(physical.supplier.to_dict(), self.supplier.to_dict())

    def test_cli_rejects_reserved_or_invalid_supplier(self):
        for details in (["UNKNOWN"], ["S002", "", ""], ["", "Test", ""]):
            with self.subTest(details=details):
                inventory = Inventory()
                with patch("builtins.input", side_effect=[
                        "1", "P001", "Laptop", "1200", "5", "2.5", *details
                ]), redirect_stdout(StringIO()):
                    main.menu_add_product(inventory)
                self.assertIsNone(inventory.search_product("P001"))

    def test_cli_validation_still_precedes_supplier_prompts(self):
        inventory = Inventory()
        inventory.add_product(self.physical)
        cases = [
            ["9"], ["1", "P001"],
            ["1", "P002", "Test", "bad"],
            ["1", "P002", "Test", "-1", "2"],
            ["1", "P002", "Test", "1", "-2"],
            ["1", "P002", "Test", "1", "2", "0"],
            ["2", "D002", "Test", "1", "2", "0"]
        ]
        for answers in cases:
            with self.subTest(answers=answers):
                with patch("builtins.input", side_effect=answers), redirect_stdout(StringIO()):
                    main.menu_add_product(inventory)
                self.assertEqual(len(inventory._products), 1)

    def test_main_cli_save_search_update_and_exit(self):
        self.write_records([self.physical.to_dict(), self.digital.to_dict()])
        output = StringIO()
        with patch("builtins.input", side_effect=[
                "1", "4", "D001", "3", "D001", "25", "5", "6"
        ]), redirect_stdout(output):
            main.main()
        saved = json.loads(self.read_file())
        self.assertEqual(saved[1]["stock"], 25)
        self.assertEqual(saved[1]["supplier"], self.supplier.to_dict())
        self.assertIn("Stock updated successfully", output.getvalue())
        self.assertIn("Supplier: S001", output.getvalue())
        self.assertIn("Program terminated", output.getvalue())

class TestInventoryAggregation(unittest.TestCase):

    def setUp(self):
        self.supplier = Supplier(
            "S001", "Test Supplier", "test@example.com"
        )
        self.product = PhysicalProduct(
            "P001", "Laptop", 1200, 5, 2.5, self.supplier
        )
        self.inventory_a = Inventory()
        self.inventory_b = Inventory()

    def test_find_existing_product(self):
        self.inventory_a.add_product(self.product)

        result = self.inventory_a.find_product("P001")

        self.assertIs(result, self.product)

    def test_find_missing_product(self):
        result = self.inventory_a.find_product("P999")

        self.assertIsNone(result)

    def test_remove_existing_product(self):
        self.inventory_a.add_product(self.product)

        result = self.inventory_a.remove_product("P001")

        self.assertTrue(result)
        self.assertIsNone(self.inventory_a.find_product("P001"))

    def test_remove_missing_product(self):
        result = self.inventory_a.remove_product("P999")

        self.assertFalse(result)

    def test_transfer_between_inventories(self):
        self.inventory_a.add_product(self.product)
        self.inventory_a.remove_product("P001")

        self.assertIs(self.product.update_stock(8), True)
        self.assertEqual(self.product._stock, 8)
        with redirect_stdout(StringIO()):
            self.product.display_information()
        self.inventory_b.add_product(self.product)

        self.assertIsNone(self.inventory_a.find_product("P001"))
        self.assertIs(
            self.inventory_b.find_product("P001"),
            self.product
        )

    def test_duplicate_product_rejected(self):
        self.assertTrue(self.inventory_a.add_product(self.product))
        self.assertFalse(self.inventory_a.add_product(self.product))
        self.assertEqual(len(self.inventory_a._products), 1)

    def test_distinct_object_with_duplicate_id_rejected(self):
        self.inventory_a.add_product(self.product)
        duplicate = DigitalProduct("P001", "Different product", 10, 2, 50, self.supplier)
        with redirect_stdout(StringIO()):
            self.assertFalse(self.inventory_a.add_product(duplicate))
        self.assertEqual(len(self.inventory_a._products), 1)
        self.assertIs(self.inventory_a.find_product("P001"), self.product)

    def test_search_delegates_to_find(self):
        with patch.object(self.inventory_a, "find_product", return_value=self.product) as lookup:
            self.assertIs(self.inventory_a.search_product("P001"), self.product)
        lookup.assert_called_once_with("P001")

    def test_remove_each_subtype_preserves_other_collection_entry(self):
        digital = DigitalProduct("D001", "Antivirus", 49.90, 20, 500, self.supplier)
        for target_id, remaining in (("P001", digital), ("D001", self.product)):
            with self.subTest(target_id=target_id):
                inventory = Inventory()
                inventory.add_product(self.product)
                inventory.add_product(digital)
                self.assertTrue(inventory.remove_product(target_id))
                self.assertIsNone(inventory.find_product(target_id))
                self.assertIsNone(inventory.search_product(target_id))
                self.assertEqual(inventory._products, [remaining])
                self.assertFalse(inventory.remove_product(target_id))

    def test_missing_removal_preserves_nonempty_collection(self):
        self.inventory_a.add_product(self.product)
        self.assertFalse(self.inventory_a.remove_product("missing"))
        self.assertEqual(self.inventory_a._products, [self.product])

    def test_empty_display_after_removing_last_entry(self):
        self.inventory_a.add_product(self.product)
        self.inventory_a.remove_product("P001")
        output = StringIO()
        with redirect_stdout(output):
            self.inventory_a.display_all()
        self.assertIn("Inventory is empty", output.getvalue())

class TestProductSubstitutability(unittest.TestCase):
    def setUp(self):
        supplier = Supplier("S001", "Test supplier", "test@example.com")
        self.products: list[Product] = [
            PhysicalProduct("P001", "Laptop", 1200, 5, 2.5, supplier),
            DigitalProduct("D001", "Antivirus", 49.90, 20, 500, supplier)
        ]

    def test_same_product_typed_consumer_accepts_each_subtype(self):
        for product in self.products:
            with self.subTest(product=type(product).__name__):
                output = StringIO()
                with redirect_stdout(output):
                    result = show_product_details(product)
                self.assertIsNone(result)
                self.assertIn(product._product_id, output.getvalue())
                self.assertIn(product._name, output.getvalue())
                self.assertIn("Supplier: S001", output.getvalue())
                fulfilment = product.get_fulfilment_info()
                self.assertIsInstance(fulfilment, str)
                self.assertTrue(fulfilment)
                self.assertTrue(output.getvalue().endswith(fulfilment + "\n"))

    def test_each_subtype_preserves_absolute_stock_update_contract(self):
        for product in self.products:
            with self.subTest(product=type(product).__name__):
                self.assertIs(product.update_stock(12), True)
                self.assertEqual(product._stock, 12)
                self.assertIs(product.update_stock(3), True)
                self.assertEqual(product._stock, 3)
                self.assertIs(product.update_stock(0), True)
                self.assertEqual(product._stock, 0)

    def test_each_subtype_rejects_negative_stock_without_mutation(self):
        for product in self.products:
            with self.subTest(product=type(product).__name__):
                original_stock = product._stock
                self.assertIs(product.update_stock(-1), False)
                self.assertEqual(product._stock, original_stock)
                self.assertIs(product.update_stock(7), True)
                self.assertEqual(product._stock, 7)

    def test_normal_inventory_operations_accept_each_subtype(self):
        inventory = Inventory()
        for product in self.products:
            with self.subTest(product=type(product).__name__):
                self.assertIs(inventory.add_product(product), True)
                found: Product | None = inventory.find_product(product._product_id)
                self.assertIsNotNone(found)
                self.assertIs(found, product)
                self.assertIs(inventory.search_product(product._product_id), product)
        output = StringIO()
        with redirect_stdout(output):
            result = inventory.display_all()
        self.assertIsNone(result)
        for product in self.products:
            self.assertIn(product._product_id, output.getvalue())
            self.assertIn(product._name, output.getvalue())

    def test_cli_stock_update_accepts_each_subtype(self):
        inventory = Inventory()
        for product in self.products:
            inventory.add_product(product)
        for product in self.products:
            with self.subTest(product=type(product).__name__):
                for quantity in (9, 0):
                    output = StringIO()
                    with patch("builtins.input", side_effect=[product._product_id, str(quantity)]):
                        with redirect_stdout(output):
                            main.menu_update_stock(inventory)
                    self.assertEqual(product._stock, quantity)
                    self.assertIn("Stock updated successfully", output.getvalue())

    def test_cli_rejected_stock_update_preserves_each_subtype(self):
        inventory = Inventory()
        for product in self.products:
            inventory.add_product(product)
        for product in self.products:
            with self.subTest(product=type(product).__name__):
                original_stock = product._stock
                for text, message in (("-1", "Stock cannot be negative"),
                                      ("bad", "Invalid stock value")):
                    output = StringIO()
                    with patch("builtins.input", side_effect=[product._product_id, text]):
                        with redirect_stdout(output):
                            main.menu_update_stock(inventory)
                    self.assertEqual(product._stock, original_stock)
                    self.assertIn(message, output.getvalue())


class TestMixedProductPolymorphism(unittest.TestCase):
    def test_mixed_inventory_dispatches_display_and_fulfilment(self):
        supplier = Supplier("S001", "Test supplier", "test@example.com")
        physical = PhysicalProduct("P001", "Laptop", 1200, 5, 2.5, supplier)
        digital = DigitalProduct("D001", "Antivirus", 49.90, 20, 500, supplier)
        inventory = Inventory()
        inventory.add_product(physical)
        inventory.add_product(digital)
        output = StringIO()

        with patch.object(physical, "display_information", wraps=physical.display_information) as physical_display:
            with patch.object(digital, "display_information", wraps=digital.display_information) as digital_display:
                with patch.object(physical, "get_fulfilment_info", wraps=physical.get_fulfilment_info) as physical_fulfilment:
                    with patch.object(digital, "get_fulfilment_info", wraps=digital.get_fulfilment_info) as digital_fulfilment:
                        with redirect_stdout(output):
                            for product in inventory._products:
                                product.display_information()
                                print(product.get_fulfilment_info())

        physical_display.assert_called_once_with()
        digital_display.assert_called_once_with()
        physical_fulfilment.assert_called_once_with()
        digital_fulfilment.assert_called_once_with()
        lines = output.getvalue().splitlines()
        self.assertIn("Weight: 2.5 kg", lines)
        self.assertIn("Download Size: 500 MB", lines)
        # Expected text comes from the existing overrides; no prediction is supplied here.
        self.assertEqual(lines.count(physical.get_fulfilment_info()), 1)
        self.assertEqual(lines.count(digital.get_fulfilment_info()), 1)
        self.assertIn("P001", output.getvalue())
        self.assertIn("D001", output.getvalue())


class TestOfficialRelationshipExperiments(unittest.TestCase):
    def test_products_display_supplier_after_deleting_local_name(self):
        supplier = Supplier("S001", "Demo Supplier", "demo@example.com")
        physical = PhysicalProduct("P001", "Laptop", 1200, 5, 2.5, supplier)
        digital = DigitalProduct("D001", "Antivirus", 49.90, 20, 500, supplier)
        supplier_id = id(supplier)
        del supplier
        output = StringIO()
        with redirect_stdout(output):
            physical.supplier.display_information()
            digital.supplier.display_information()
        self.assertEqual(id(physical.supplier), supplier_id)
        self.assertIs(physical.supplier, digital.supplier)
        self.assertEqual(output.getvalue().count("Supplier: S001"), 2)

    def test_two_orders_create_separate_lines_referencing_one_product(self):
        supplier = Supplier("S001", "Demo Supplier", "demo@example.com")
        product = PhysicalProduct("P001", "Laptop", 1200, 5, 2.5, supplier)
        first = Order("O001")
        second = Order("O002")
        first.add_order_line(product, 1)
        second.add_order_line(product, 2)
        self.assertIsNot(first._order_lines[0], second._order_lines[0])
        self.assertIs(first._order_lines[0].product, product)
        self.assertIs(second._order_lines[0].product, product)
        self.assertTrue(first.remove_order_line(0))
        self.assertEqual(first.calculate_total(), 0.0)
        self.assertEqual(second.calculate_total(), 2400.0)
        self.assertEqual(product.price, 1200.0)


class TestOrderComposition(unittest.TestCase):
    def setUp(self):
        supplier = Supplier("S001", "Test supplier", "test@example.com")
        self.physical = PhysicalProduct("P001", "Laptop", 1200, 5, 2.5, supplier)
        self.digital = DigitalProduct("D001", "Antivirus", 49.90, 20, 500, supplier)
        self.order = Order("O001")

    def test_empty_order_has_float_zero_total(self):
        self.assertEqual(self.order.calculate_total(), 0.0)
        self.assertIsInstance(self.order.calculate_total(), float)

    def test_price_is_read_only_and_uses_existing_price(self):
        for product in (self.physical, self.digital):
            with self.subTest(product=type(product).__name__):
                self.assertEqual(product.price, product._price)
                self.assertIsInstance(product.price, float)
                with self.assertRaises(AttributeError):
                    product.price = 1.0

    def test_subtotal_and_multi_line_total(self):
        self.assertIsNone(self.order.add_order_line(self.physical, 2))
        self.assertIsNone(self.order.add_order_line(self.digital, 3))
        self.assertAlmostEqual(self.order._order_lines[0].calculate_subtotal(), 2400.0)
        self.assertAlmostEqual(self.order._order_lines[1].calculate_subtotal(), 149.70)
        self.assertAlmostEqual(self.order.calculate_total(), 2549.70)

    def test_total_delegates_to_line_subtotals(self):
        self.order.add_order_line(self.physical, 2)
        self.order.add_order_line(self.digital, 3)
        with patch.object(self.order._order_lines[0], "calculate_subtotal", return_value=10.0) as first:
            with patch.object(self.order._order_lines[1], "calculate_subtotal", return_value=20.0) as second:
                self.assertEqual(self.order.calculate_total(), 30.0)
        first.assert_called_once_with()
        second.assert_called_once_with()

    def test_invalid_quantity_does_not_add_line(self):
        self.order.add_order_line(self.physical, 1)
        for quantity in (0, -1, 1.5, "2", True, False, None):
            with self.subTest(quantity=quantity), self.assertRaises(ValueError):
                self.order.add_order_line(self.digital, quantity)
        self.assertEqual(len(self.order._order_lines), 1)
        self.assertEqual(self.order.calculate_total(), 1200.0)

    def test_invalid_order_id_rejected(self):
        for order_id in ("", " ", None, 7):
            with self.subTest(order_id=order_id), self.assertRaises(ValueError):
                Order(order_id)

    def test_remove_line_updates_total_and_preserves_other_line(self):
        self.order.add_order_line(self.physical, 2)
        self.order.add_order_line(self.digital, 3)
        self.assertTrue(self.order.remove_order_line(0))
        self.assertEqual(len(self.order._order_lines), 1)
        self.assertIs(self.order._order_lines[0].product, self.digital)
        self.assertAlmostEqual(self.order.calculate_total(), 149.70)
        self.assertTrue(self.order.remove_order_line(0))
        self.assertEqual(self.order.calculate_total(), 0.0)

    def test_invalid_removal_index_preserves_lines(self):
        self.assertFalse(self.order.remove_order_line(0))
        self.order.add_order_line(self.physical, 1)
        for index in (-1, 1, 100):
            with self.subTest(index=index):
                self.assertFalse(self.order.remove_order_line(index))
                self.assertEqual(len(self.order._order_lines), 1)
                self.assertEqual(self.order.calculate_total(), 1200.0)

    def test_line_operations_do_not_change_product_stock(self):
        self.order.add_order_line(self.physical, 10)
        self.order.add_order_line(self.digital, 30)
        self.order.remove_order_line(0)
        self.assertEqual(self.physical._stock, 5)
        self.assertEqual(self.digital._stock, 20)

    def test_display_includes_lines_quantities_subtotals_and_total(self):
        self.order.add_order_line(self.physical, 2)
        self.order.add_order_line(self.digital, 3)
        output = StringIO()
        with redirect_stdout(output):
            self.order.display_information()
        for text in ("Order: O001", "Line 0", "Line 1", "Laptop", "Antivirus",
                     "Quantity: 2", "Quantity: 3", "Subtotal: $2400.00",
                     "Subtotal: $149.70", "Total: $2549.70"):
            self.assertIn(text, output.getvalue())

    def test_empty_order_display(self):
        output = StringIO()
        with redirect_stdout(output):
            self.order.display_information()
        self.assertIn("Order: O001", output.getvalue())
        self.assertIn("Total: $0.00", output.getvalue())


if __name__ == "__main__":
    unittest.main()
